<?php
    header("Location: views/login.php");

// If the user is logged in, continue with the rest of the index.php code
?>
