      <footer class="main-footer">
        <div class="footer-left">
         <div class="copyright"> Copyright &copy; 2024 Task Design And Develop By <strong><a href="#"><span >Task</span></strong></a>. All Rights Reserved</div>
         
        </div>
        <div class="footer-right">
        </div>
      </footer>
    </div>
  </div>
  <!-- General JS Scripts -->
  
  <!-- JS Libraies -->
  <!--<script src="../assets/admin/bundles/apexcharts/apexcharts.min.js"></script>-->
  <script src="../assets/admin/bundles/jqvmap/dist/jquery.vmap.min.js"></script>
  <!-- <script src="../assets/admin/bundles/jqvmap/dist/maps/jquery.vmap.world.js"></script> -->
  <!-- Page Specific JS File -->
  <script src="../assets/admin/js/page/index.js"></script>
  <!-- Template JS File -->
  <script src="../assets/admin/js/scripts.js"></script>
  <!-- Custom JS File -->
  <script src="../assets/admin/js/custom.js"></script>
  <script src="../assets/admin/bundles/datatables/datatables.min.js"></script>
  <script src="../assets/admin/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
  <script src="../assets/admin/bundles/datatables/export-tables/dataTables.buttons.min.js"></script>
  <script src="../assets/admin/bundles/datatables/export-tables/buttons.flash.min.js"></script>
  <script src="../assets/admin/bundles/datatables/export-tables/jszip.min.js"></script>
  <script src="../assets/admin/bundles/datatables/export-tables/pdfmake.min.js"></script>
  <script src="../assets/admin/bundles/datatables/export-tables/vfs_fonts.js"></script>
  <script src="../assets/admin/bundles/datatables/export-tables/buttons.print.min.js"></script>
  <script src="../assets/admin/js/page/datatables.js"></script>
  <script src="../assets/admin/action.js"></script>
 
</body>

</html>